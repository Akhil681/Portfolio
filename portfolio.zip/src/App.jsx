import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Menu from './component/menu/Menu'
import 'bootstrap/dist/css/bootstrap.min.css';
import Mainbanner from './component/mainbanner/Mainbanner'

function App() {

  return (
    <>
    <Menu/>
    <Mainbanner/>
   
    
    </>
  )
}

export default App
